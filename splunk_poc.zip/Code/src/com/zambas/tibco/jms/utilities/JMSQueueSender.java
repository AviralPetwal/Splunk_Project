package com.zambas.tibco.jms.utilities;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;

public class JMSQueueSender {

	static String asyncJmsSendServer = "tcp://localhost:7224";
	static String asyncJmsSendUsername = "admin";
	static String asyncJmsSendPassword = "";

	public static void main(String[] args) throws InterruptedException,
			IOException {
		System.out.println("Started sending the message...");
		long a = System.currentTimeMillis();

		QueueConnectionFactory myQCF = new com.tibco.tibjms.TibjmsQueueConnectionFactory(
				asyncJmsSendServer);

		javax.jms.Queue myQ = new com.tibco.tibjms.TibjmsQueue("lhsoa.sample");

		try {
			QueueConnection qCon = myQCF.createQueueConnection(
					asyncJmsSendUsername, asyncJmsSendPassword);
			QueueSession qSess = qCon.createQueueSession(false,
					Session.AUTO_ACKNOWLEDGE);
			MessageProducer qProd = qSess.createProducer(myQ);

			qProd.setDeliveryMode(DeliveryMode.PERSISTENT);
			qProd.setDeliveryMode(com.tibco.tibjms.Tibjms.RELIABLE_DELIVERY);

			int i = 0;
			for (i = 0; i < 100; i++) {

				try {
					TextMessage requestMsg = qSess
							.createTextMessage(readFile("C:\\agent.log.log"));
					qProd.send(requestMsg);
					System.out
							.println("###########Message sent to the queue############");
					//Thread.sleep(100000);
				} catch (JMSException e) {
					e.printStackTrace();
					System.exit(0);
				}
			}
			qSess.close();
			qCon.close();

			System.out.println(System.currentTimeMillis() - a);
		} catch (JMSException jmse) {
			System.out.println("JMS Exception" + jmse.getMessage());
			jmse.printStackTrace();
		}
		System.out.println("Finished...");
	}

	public static String readFile(String file) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line = null;
		StringBuilder stringBuilder = new StringBuilder();
		String ls = System.getProperty("line.separator");
		while ((line = reader.readLine()) != null) {
			stringBuilder.append(line);
			stringBuilder.append(ls);
		}
		return stringBuilder.toString();
	}

}
