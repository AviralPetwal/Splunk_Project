package com.zambas.tibco.jms.utilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

public class xml_to_json {

	public static void main(String[] args) throws FileNotFoundException {
		BufferedReader reader;
		try {
			  File file = new File("C:\\Users\\apetwal\\Desktop\\splunk\\data\\raw_log.txt"); 
			  PrintWriter writer =new PrintWriter("C:\\Users\\apetwal\\Desktop\\splunk\\data\\json_raw_log.txt");
			  int PRETTY_PRINT_INDENT_FACTOR = 4;
			  BufferedReader br = new BufferedReader(new FileReader(file)); 
			  StringBuilder full=new StringBuilder();
			  String st; 
			  while ((st = br.readLine()) != null) { 
				  full.append(st);
//				  System.out.println(st);
			  }
			  String finalString=full.toString();
//			  System.out.println(finalString);
	           JSONObject xmlJSONObj = XML.toJSONObject(finalString);
	           
	            String jsonPrettyPrintString = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);
	            System.out.println(jsonPrettyPrintString);
	            writer.println(jsonPrettyPrintString);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
