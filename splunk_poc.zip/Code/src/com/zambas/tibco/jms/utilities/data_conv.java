package com.zambas.tibco.jms.utilities;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;


public class data_conv {
	public static String readFileAsString(String fileName)throws Exception 
	  { 
	    String data = ""; 
	    data = new String(Files.readAllBytes(Paths.get(fileName))); 
	    return data; 
	  } 
	public static void main(String[] args) throws Exception {
		String st="\\\"";
		String data = readFileAsString("C:\\Users\\apetwal\\Desktop\\splunk\\data\\curl_trial.txt"); 
		String master = "Hello World Baeldung!";
		String target = "\"";
		String replacement = "\\\\\\\"";
		String processed = data.replace(target, replacement);
		System.out.println(processed);
	}

}