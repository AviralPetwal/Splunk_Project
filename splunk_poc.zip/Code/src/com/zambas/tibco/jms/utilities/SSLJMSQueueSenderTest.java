package com.zambas.tibco.jms.utilities;

import javax.jms.*;

public class SSLJMSQueueSenderTest {
	
	// parameters required for asyncronous communication for sending messages
	// (may also be read from a properties file)
	static String asyncJmsSendServer   = "ssl://localhost:7243";
	static String asyncJmsSendUsername = "admin";
	static String asyncJmsSendPassword = "";
	static String certificateLocation = "C:\\zambas\\Certificates\\LufthansaCA.cer";
	
	public static void main(String[] args) {
		System.out.println("Started...");
		long a = System.currentTimeMillis();
	
      	com.tibco.tibjms.TibjmsQueueConnectionFactory  myQCF = 
      			new com.tibco.tibjms.TibjmsQueueConnectionFactory(asyncJmsSendServer);

      	javax.jms.Queue myQ = new com.tibco.tibjms.TibjmsQueue("test");
	
		try {
			//Provide certificate location
			myQCF.setSSLTrustedCertificate(certificateLocation);
			//Set verify hostname to false
			myQCF.setSSLEnableVerifyHostName(false);
	  
			QueueConnection qCon = myQCF.createQueueConnection(asyncJmsSendUsername,
		                                              asyncJmsSendPassword);
			QueueSession qSess = qCon.createQueueSession(false,
	                                              Session.AUTO_ACKNOWLEDGE);
			MessageProducer qProd = qSess.createProducer(myQ);
			
			qProd.setDeliveryMode(DeliveryMode.PERSISTENT);
			qProd.setDeliveryMode(com.tibco.tibjms.Tibjms.RELIABLE_DELIVERY);
	
			int i = 0;
			for (i = 0; i < 2; i++) {
				TextMessage tMsg = qSess.createTextMessage();
				tMsg.setText("Hello, this is a sample!");
				tMsg.setBooleanProperty("JMS_TIBCO_COMPRESS", true);
	
				try {
					qProd.send(tMsg);
				} catch (JMSException e) {
					e.printStackTrace();
					System.exit(0);
				}
			}
			qSess.close();
			qCon.close();
	
			System.out.println(System.currentTimeMillis() - a);
		} catch (JMSException jmse) {
			System.out.println("JMS Exception" + jmse.getMessage());
			jmse.printStackTrace();
		}
		System.out.println("Finished...");
	}
}
