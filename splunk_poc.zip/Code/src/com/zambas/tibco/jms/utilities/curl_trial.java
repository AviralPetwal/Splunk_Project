package com.zambas.tibco.jms.utilities;

import java.nio.file.Files;
import java.nio.file.Paths;

public class curl_trial {
	public static String readFileAsString(String fileName)throws Exception 
	  { 
	    String data = ""; 
	    data = new String(Files.readAllBytes(Paths.get(fileName))); 
	    return data; 
	  } 

	public static void main(String[] args) throws Exception {
		String data = readFileAsString("C:\\Users\\apetwal\\Desktop\\splunk\\data\\curl_trial.txt"); 
		String rpt="\\\"";
		String rrp="";
		String text = data.replace(rpt, rrp);
		String target = "\"";
		String replacement = "\\\"";
		text = text.replace(target, replacement);
//		text=text.replace(System.getProperty("line.separator"), "");
		System.out.println(text);
		String testCurlCommand = "curl -k  http://localhost:8088/services/collector -H \"Authorization:Splunk caa15c52-60b5-4421-8ee2-96bb7a086e31\" -d \"{\\\"sourcetype\\\":  \\\"_json\\\",\\\"event\\\": "+text+"}\"";
		try {
	        Process p = Runtime.getRuntime().exec(testCurlCommand);
	        System.out.println("Done");
	    }
		catch(Exception e) {
			System.out.println(e);
		}
	}

}
