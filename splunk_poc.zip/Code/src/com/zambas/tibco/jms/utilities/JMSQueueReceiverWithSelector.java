package com.zambas.tibco.jms.utilities;

import javax.jms.*;
/*
 * This program creates a queue receiver which receives a message
 * from a queue, based on the message selector defined. Each message
 * has a boolean and a string property set as shown below.
 * 
 * To receive the messages sent in the above example, set the selector
 * to the following values:
 * 1.	selector = "(Property1 = TRUE) AND (Property2 = 'abcd')";
 * 2.	selector = "(Property1 = FALSE) AND (Property2 = 'efgh')";
 */

public class JMSQueueReceiverWithSelector {
	// parameters required for asyncronous communication for sending messages
	// (may also be read from a properties file)
	static String asyncSSLJmsReceiveServer   = "tcp://localhost:7222";
	static String asyncJmsSendUsername = "admin";
	static String asyncJmsSendPassword = "";
	
			
	public static void main(String[] args) {
		Message message = null;
		System.out.println("Started...");
		long a = System.currentTimeMillis();
		
		QueueConnectionFactory myQCF = 
				new com.tibco.tibjms.TibjmsQueueConnectionFactory(asyncSSLJmsReceiveServer);

		try {
			QueueConnection qCon = myQCF.createQueueConnection(asyncJmsSendUsername,
                    asyncJmsSendPassword);
			QueueSession qSess = qCon.createQueueSession(false,
					Session.AUTO_ACKNOWLEDGE);
			Queue myQ = qSess.createQueue("test");
			qCon.start();
			
			String selector;
		
			//receive the message with Property1 = true and Property2 = 'abcd'
			selector = "(Property1 = TRUE) AND (Property2 = 'abcd')";
			MessageConsumer qReader = qSess.createConsumer(myQ, selector);
			//poll for queue messages indefinitely
			while(true)
			{
				message = qReader.receive();
				if(message == null)
					break;
				System.out.println("Received message: " + message + "\n");
			}
			qSess.close();
			qCon.close();

			System.out.println(System.currentTimeMillis() - a);
			System.out.println("Finished...");
		} catch (JMSException e) {
			e.printStackTrace();
			System.exit(0);
		}
	}
}
