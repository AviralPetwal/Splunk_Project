package com.zambas.tibco.jms.utilities;

import javax.jms.*;


public class SSLJMSQueueReceiverTest {
	// parameters required for asyncronous communication for receiving messages
	// (may also be read from a properties file)
	static String asyncSSLJmsReceiveServer   = "ssl://localhost:7243";
	static String asyncJmsReceiveUsername = "admin";
	static String asyncJmsReceivePassword = "";
	static String certificateLocation = "D:\\zambas\\conf\\tibco\\bw\\apps\\certificate\\lh\\cer\\LufthansaCA.cer";
	
	public static void main(String[] args) {
	      Message message = null;
	      com.tibco.tibjms.TibjmsQueueConnectionFactory  myQCF = 
	    		  	new com.tibco.tibjms.TibjmsQueueConnectionFactory(asyncSSLJmsReceiveServer);

	      javax.jms.Queue myQ = new com.tibco.tibjms.TibjmsQueue("test");

	      try {
	    	  //Provide certificate location
	    	  myQCF.setSSLTrustedCertificate(certificateLocation);
	    	  //Set verify hostname to false
	    	  myQCF.setSSLEnableVerifyHostName(false);
				
	    	  QueueConnection qCon = myQCF.createQueueConnection(asyncJmsReceiveUsername,
	    			  asyncJmsReceivePassword);

	    	  QueueSession qSess = qCon.createQueueSession(false,
	                  Session.AUTO_ACKNOWLEDGE);

	    	  MessageConsumer qReader = qSess.createConsumer(myQ);
				
				//Start connection to receive messages
				qCon.start();
		
				/* read queue messages */
				while (true) {
					message = qReader.receive();
					if (message == null)
						break;
					System.out.println("Received message: \n" + message);
				}
				qCon.close();
	      } catch (JMSException jmse) {
	         System.out.println("JMS Exception" + jmse.getMessage());
	      }
	   }

}
