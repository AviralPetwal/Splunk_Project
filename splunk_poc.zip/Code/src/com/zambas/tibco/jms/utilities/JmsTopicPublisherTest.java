
package com.zambas.tibco.jms.utilities;


import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;


public class JmsTopicPublisherTest {
	
	// parameters required for asyncronous communication for sending messages
	// (may also be read from a properties file)
	static String asyncJmsSendServer   = "tcp://localhost:7222";
	static String asyncJmsSendUsername = "admin";
	static String asyncJmsSendPassword = "";
	
 public static void main(String[] args) throws InterruptedException {
    System.out.println("Started...");
    long a = System.currentTimeMillis();

    TopicConnectionFactory myTCF = 
		new com.tibco.tibjms.TibjmsTopicConnectionFactory(asyncJmsSendServer);

    javax.jms.Topic myT = new com.tibco.tibjms.TibjmsTopic("zambas.ext.SMILEBESTPRICE.x");

    try {
  	  TopicConnection tCon = myTCF.createTopicConnection(asyncJmsSendUsername,
			                                              asyncJmsSendPassword);
       TopicSession tSess = tCon.createTopicSession(false,
                                                    Session.AUTO_ACKNOWLEDGE);
       MessageProducer tProd = tSess.createProducer(myT);

       int i = 0;
       for (i = 0; i < 50; i++) {
          TextMessage tMsg = tSess.createTextMessage();
          tMsg.setText("Hello, this is a sample!");
          tMsg.setBooleanProperty("JMS_TIBCO_COMPRESS", true);

          try {
             tProd.send(tMsg);
             Thread.sleep(2000);
          } catch (JMSException e) {
             e.printStackTrace();
             System.exit(0);
          }
       }
       tSess.close();
       tCon.close();

       System.out.println(System.currentTimeMillis() - a);
    } catch (JMSException jmse) {
       System.out.println("JMS Exception" + jmse.getMessage());
       jmse.printStackTrace();
    }
    System.out.println("Finished...");
 }
}
