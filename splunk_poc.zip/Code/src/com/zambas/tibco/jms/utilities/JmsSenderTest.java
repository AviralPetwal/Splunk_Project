package com.zambas.tibco.jms.utilities;


import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;


public class JmsSenderTest {
	
	// parameters required for asyncronous communication for sending messages
	// (may also be read from a properties file)
	static String asyncJmsSendServer   = "tcp://localhost:7222";
	static String asyncJmsSendUsername = "admin";
	static String asyncJmsSendPassword = "";
	public static void main(String[] args) throws InterruptedException {
	      System.out.println("Started...");
	      long a = System.currentTimeMillis();

	      QueueConnectionFactory myQCF = 
			new com.tibco.tibjms.TibjmsQueueConnectionFactory(asyncJmsSendServer);

	      javax.jms.Queue myQ = new com.tibco.tibjms.TibjmsQueue("test.zambas");

	      try {
	         QueueConnection qCon = myQCF.createQueueConnection(asyncJmsSendUsername,
				                                              asyncJmsSendPassword);
	         QueueSession qSess = qCon.createQueueSession(false,
	                                                      Session.AUTO_ACKNOWLEDGE);
	         MessageProducer qProd = qSess.createProducer(myQ);

	         qProd.setDeliveryMode(DeliveryMode.PERSISTENT);
	         qProd.setDeliveryMode(com.tibco.tibjms.Tibjms.RELIABLE_DELIVERY);

	         int i = 0;
	         for (i = 0; i < 5; i++) {
	            TextMessage tMsg = qSess.createTextMessage();
	            tMsg.setText("Hello, this is a sample!");
	            tMsg.setBooleanProperty("JMS_TIBCO_COMPRESS", true);

	            try {
	            	tMsg.setJMSTimestamp(1517332196812L);
	               qProd.send(tMsg);
	               Thread.sleep(20000);
	               System.out.println(tMsg.getJMSTimestamp());
	              
	            } catch (JMSException e) {
	               e.printStackTrace();
	               System.exit(0);
	            }
	         }
	         qSess.close();
	         qCon.close();

	         System.out.println(System.currentTimeMillis() - a);
	      } catch (JMSException jmse) {
	         System.out.println("JMS Exception" + jmse.getMessage());
	         jmse.printStackTrace();
	      }
	      System.out.println("Finished...");
	   }

}
