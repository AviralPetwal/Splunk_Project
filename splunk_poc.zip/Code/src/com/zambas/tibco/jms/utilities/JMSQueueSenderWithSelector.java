package com.zambas.tibco.jms.utilities;

import javax.jms.*;

public class JMSQueueSenderWithSelector {
	
	// parameters required for asyncronous communication for sending messages
	// (may also be read from a properties file)
	static String asyncJmsSendServer   = "tcp://localhost:7222";
	static String asyncJmsSendUsername = "admin";
	static String asyncJmsSendPassword = "";
		
	public static void main(String[] args) {
		System.out.println("Started...");
		long a = System.currentTimeMillis();
		
		QueueConnectionFactory myQCF = 
				new com.tibco.tibjms.TibjmsQueueConnectionFactory(asyncJmsSendServer);

		javax.jms.Queue myQ = new com.tibco.tibjms.TibjmsQueue("test");
	
		try {
			QueueConnection qCon = myQCF.createQueueConnection(asyncJmsSendUsername,
					asyncJmsSendPassword);
			QueueSession qSess = qCon.createQueueSession(false,
					Session.AUTO_ACKNOWLEDGE);
			MessageProducer tProd = qSess.createProducer(myQ);

			//Send message-1 over Queue
			TextMessage qMsg = qSess.createTextMessage();
			qMsg.setText("Test message 1");
			qMsg.setBooleanProperty("Property1", true);
			qMsg.setStringProperty("Property2", "abcd");
			tProd.send(qMsg);

			//Send message-2 over Queue
			qMsg = qSess.createTextMessage();
			qMsg.setText("Test message 2");
			qMsg.setBooleanProperty("Property1", false);
			qMsg.setStringProperty("Property2", "efgh");
			tProd.send(qMsg);
			
			qSess.close();
			qCon.close();

			System.out.println(System.currentTimeMillis() - a);
			System.out.println("Finished...");
		} catch (JMSException e) {
			e.printStackTrace();
			System.exit(0);
		}
	}
}
