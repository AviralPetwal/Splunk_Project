package com.zambas.tibco.jms.utilities;

import java.util.Hashtable;
import java.util.Vector;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.QueueConnection;
import javax.jms.Session;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;

public class SSLJMSTopicDurableSubscriberTest {
	
	// parameters required for asyncronous communication for receiving messages
		// (may also be read from a properties file)
		static String asyncJmsReceiveServer   = "ssl://localhost:7243";
		static String asyncJmsReceiveUsername = "admin";
		static String asyncJmsReceivePassword = "";
		static String asyncJmsTopicName = "zambas.ext.SMILEBESTPRICE.x";
		static String asyncJmsTopicDurableName = "DS_BESTPRICE_LHCOM";
		static String certificateLocation = "D:\\zambas\\conf\\tibco\\bw\\apps\\certificate\\lh\\cer\\LufthansaCA.cer";
		

	    // SSL options
		static boolean     ssl_trace                = false;
		static boolean     ssl_debug_trace          = false;
		static Vector      ssl_trusted              = new Vector();
		static String      ssl_hostname             = null;
		static String      ssl_identity             = null;
		static String      ssl_key                  = null;
		static String      ssl_password             = null;
		static String      ssl_vendor               = "j2se";
		static String      ssl_ciphers              = null;
		static boolean     disable_verify_host_name = true;
		static boolean disable_verify_host = false;

		public static void main(String[] args) {
      Message message = null;


      try {
    	  Hashtable environment = new Hashtable();
    	  ssl_trusted.addElement(certificateLocation);
          if (ssl_vendor != null) {
              environment.put(com.tibco.tibjms.TibjmsSSL.VENDOR, ssl_vendor);
          }

          // set trace for client-side operations, loading of certificates
          // and other
          if (ssl_trace) {
              environment.put(com.tibco.tibjms.TibjmsSSL.TRACE, new Boolean(true));
          }

          // set vendor trace. Has no effect for "j2se", "entrust6" uses
          // this to trace SSL handshake
          if (ssl_debug_trace) {
              environment.put(com.tibco.tibjms.TibjmsSSL.DEBUG_TRACE, new Boolean(true));
          }

          // set trusted certificates if specified
          if (ssl_trusted.size() != 0) {
              environment.put(com.tibco.tibjms.TibjmsSSL.TRUSTED_CERTIFICATES, ssl_trusted);
          }

          // set expected host name in the certificate if specified
          if (ssl_hostname != null) {
              environment.put(com.tibco.tibjms.TibjmsSSL.EXPECTED_HOST_NAME, ssl_hostname);
          }

          //
          if (ssl_ciphers != null) {
              environment.put(com.tibco.tibjms.TibjmsSSL.CIPHER_SUITES, ssl_ciphers);
          }

          if (disable_verify_host_name) {
            environment.put(com.tibco.tibjms.TibjmsSSL.ENABLE_VERIFY_HOST_NAME, new Boolean(false));
          }

          if (disable_verify_host || ssl_trusted.size()==0) {
             environment.put(com.tibco.tibjms.TibjmsSSL.ENABLE_VERIFY_HOST, new Boolean(false));
          }
			
          TopicConnectionFactory myTCF = 
         			new com.tibco.tibjms.TibjmsTopicConnectionFactory(asyncJmsReceiveServer,null,environment);

          javax.jms.Topic myT = new com.tibco.tibjms.TibjmsTopic(asyncJmsTopicName);
           
    	  TopicConnection tCon = myTCF.createTopicConnection(asyncJmsReceiveUsername,
    			  												asyncJmsReceivePassword);
    	  TopicSession tSess = tCon.createTopicSession(false,
               Session.AUTO_ACKNOWLEDGE);

         MessageConsumer tSub = tSess.createDurableSubscriber(myT,asyncJmsTopicDurableName);
         tCon.start();
         int i=0;
         while (true) {
        	 i++;
            message = tSub.receive();
            if (message == null)
               break;
            System.err.println("Received message: " + message);
            System.err.println("Total Message Recieveed: " +  i);
         }

         tSess.close();
         tCon.close();
      } catch (JMSException jmse) {
         System.out.println("JMS Exception" + jmse.getMessage());
      }
   }
}

