package com.zambas.tibco.jms.utilities;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

public class JmsReceiverTest {

	// parameters required for asyncronous communication for receiving messages
		// (may also be read from a properties file)
		static String asyncJmsReceiveServer   = "tcp://BLRL78787:7222";
		static String asyncJmsReceiveUsername = "admin";
		static String asyncJmsReceivePassword = "";
		public static void main(String[] args) {

	      Message message = null;
	      QueueConnectionFactory myQCF = new com.tibco.tibjms.TibjmsQueueConnectionFactory(asyncJmsReceiveServer);

	      javax.jms.Queue myQ = new com.tibco.tibjms.TibjmsQueue("SplunkQueue");

	      try {
	         QueueConnection qCon = myQCF.createQueueConnection(asyncJmsReceiveUsername,
				                                               asyncJmsReceivePassword);
	         QueueSession qSess = qCon.createQueueSession(false,
	               Session.AUTO_ACKNOWLEDGE);
	         int count = 3;
	         String address="C:\\Users\\apetwal\\Desktop\\splunk\\data\\series\\json_try_raw_log.txt";
	         PrintWriter writer =new PrintWriter(address);
	         MessageConsumer qReader = qSess.createConsumer(myQ);
	         qCon.start();
	         int PRETTY_PRINT_INDENT_FACTOR = 4;
	         while (true) {
	            message = qReader.receive();
	            if (message == null)
	               break;
	            	
	            	File file =new File (address);
//	            	double bytes=file.length();
	            	double killobytes=file.length()/1024;
	            	double megabytes=killobytes/1024;
//	            	System.out.println(bytes);
//	            	System.out.println(killobytes);
//	            	System.out.println(megabytes);
	            	if (megabytes>490) {
	            		count ++;
	            		address="C:\\Users\\apetwal\\Desktop\\splunk\\data\\series\\json_try_raw_log"+Integer.toString(count)+".txt";
	            		writer =new PrintWriter(address);
	            	}
	            	else {
	            		
	            	
	            		String full=message.toString();
//						System.out.println("Received message: " + message);
			           JSONObject xmlJSONObj = XML.toJSONObject(full);
			            String jsonPrettyPrintString = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);
//			            System.out.println(jsonPrettyPrintString);
//			            writer.println(jsonPrettyPrintString);
			            String data=jsonPrettyPrintString;
			    		String rpt="\\\"";
			    		String rrp="";
			    		String text = data.replace(rpt, rrp);
			            String target = "\"";
			    		String replacement = "\\\"";
			    		text = text.replace(target, replacement);
			    		text=text.replace(System.getProperty("line.separator"), "");

			    		String testCurlCommand = "curl -k  http://localhost:8088/services/collector -H \"Authorization:Splunk caa15c52-60b5-4421-8ee2-96bb7a086e31\" -d \"{\\\"sourcetype\\\":  \\\"_json\\\",\\\"event\\\": "+text+"}\"";
			    		try {
			    	        Process p = Runtime.getRuntime().exec(testCurlCommand);
			    	        System.out.println("Done");
			    	    }
			    		catch(Exception e) {
			    			System.out.println(e);
			    		}

	            	}
	            
	            
	         }
	         
	         qSess.close();
	         qCon.close();
	         writer.close();
	      } catch (JMSException jmse) {
	         System.out.println("JMS Exception" + jmse.getMessage());
	      }
			catch(IOException e){
				System.out.println("File Not Found");
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   }


}
