package com.zambas.tibco.jms.utilities;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;

public class JMSTopicSubscriberTest {

	// parameters required for asyncronous communication for receiving messages
			// (may also be read from a properties file)
			static String asyncJmsReceiveServer   = "tcp://localhost:7222";
			static String asyncJmsReceiveUsername = "admin";
			static String asyncJmsReceivePassword = "";
			static String asyncJmsTopicName = "zambas.ext.SMILEBESTPRICE.x";

	public static void main(String[] args) {
	      Message message = null;
	      TopicConnectionFactory myTCF = 
	    			new com.tibco.tibjms.TibjmsTopicConnectionFactory(asyncJmsReceiveServer);

	      javax.jms.Topic myT = new com.tibco.tibjms.TibjmsTopic(asyncJmsTopicName);

	      try {
	    	  TopicConnection tCon = myTCF.createTopicConnection(asyncJmsReceiveUsername,
	    			  												asyncJmsReceivePassword);
	    	  TopicSession tSess = tCon.createTopicSession(false,
	               Session.AUTO_ACKNOWLEDGE);

	         MessageConsumer tSub = tSess.createConsumer(myT);
	         tCon.start();

	         while (true) {
	            message = tSub.receive();
	            if (message == null)
	               break;
	            System.err.println("Received message: " + message);
	         }

	         tSess.close();
	         tCon.close();
	      } catch (JMSException jmse) {
	         System.out.println("JMS Exception" + jmse.getMessage());
	      }
	   }

}
