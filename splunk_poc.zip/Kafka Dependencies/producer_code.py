import pykafka
import time
path=r'C:\Users\apetwal\Desktop\splunk\data\producer_trial.txt'
count = 0
def get_text(tts,ccount):
#    text="how are you"
    ccount=ccount+1
    tts=tts+"\n"+str(ccount)
    print(tts)
    text_as_bytes=str.encode(tts)
    producer.produce(text_as_bytes)
    return(ccount)

if __name__ == "__main__":
    client = pykafka.client.KafkaClient("localhost:9092")
    print ("topics",client.topics)
    producer = client.topics[b'aviralp'].get_producer()
while(1):

    print("written on stream")
    with open(path, 'r') as file:
        data = file.read()
        count=get_text(data,count)
        time.sleep(2)