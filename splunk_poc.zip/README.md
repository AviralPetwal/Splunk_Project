## SPLUNK POC

## Purpose
To setup a log analytics environment through which different application logs in real time can be inspected and relevant reports and dashboards are generated to make working environment more presentable and efficient. 

## Contents
	Code : Contains code related to uploading data on splunk server from JMS queue
	Kafka Dependencies : Contains commands to setup Kafka cluster and code to generate Kafka producer
	Prometheus_Data_Extractor : Contains code to retrieve data from Prometheus server and save it as dataframes.
	Documentation : Project documentation and PPT
 
## Configuration steps
	Step1 : In Eclipse import the project as an JAVA Project
	Step2 : Verify if all jars are added to build path
	Step3 : Configure HEC on Splunk Server
## Operating instructions
    Step 1 : Run the BW process to fill JMS queue
    Step 2 : Run JmsReceiverTest.java
    Step 3 : Enable the HEC creaated on Splunk Server

## Contact information for the distributor or programmer
	1A		: R&D Team