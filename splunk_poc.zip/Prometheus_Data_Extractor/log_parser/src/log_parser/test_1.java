package log_parser;
import java.io.File;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.io.BufferedReader;
import java.io.FileReader;

public class test_1 {
	public static void listFilesForFolder(final File folder) {
		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			}else {
				System.out.println(fileEntry.getName());
				Clear_data(fileEntry.getName());
				
			}
		}
	}

	public static void main(String[] args) {
		/*File file = new File("C:\\Users\\apetwal\\Desktop\\test_log\\test_logs\\part1\\rawdata_10000_1547805600_120-395.txt");
	    if (!file.exists()) {
	      System.out.println(args[0] + " does not exist.");
	      return;
	    }
	    if (!(file.isFile() && file.canRead())) {
	      System.out.println(file.getName() + " cannot be read from.");
	      return;
	    }
	    try {
	      FileInputStream fis = new FileInputStream(file);
	      char current;
	      while (fis.available() > 0) {
	        current = (char) fis.read();
	        System.out.print(current);
	      }
	    } catch (IOException e) {
	      e.printStackTrace();
	    }*/
		String get_dir="C:\\Users\\apetwal\\Desktop\\promextracted_dataframes\\";
		String parti_dir="test";
		final File readdir= new File(get_dir+parti_dir+"\\raw\\");
		listFilesForFolder(readdir);
		
		System.out.println("done processing");
		

	}
	public static void Clear_data(String s) {
		BufferedReader reader;
		try {
			String get_dir_temp="C:\\Users\\apetwal\\Desktop\\promextracted_dataframes\\";
			String parti_dir="test";
			String get_dir=get_dir_temp+parti_dir+"\\raw\\";
			String put_dir=get_dir_temp+parti_dir+"\\logs\\";
			reader=new BufferedReader(new FileReader(get_dir+s));
			PrintWriter writer =new PrintWriter(put_dir+"clear_"+s);
			String line=reader.readLine();
			while(line!=null) {
				if (line.contains("<13>")) {
					//System.out.println(line);
					String[] parts = line.split("<13>1");
					writer.println("<13>"+parts[1].trim());

				}
				if (line.contains("<4>")) {
					//System.out.println(line);
					String[] parts = line.split("<4>");
					writer.println("<4>"+parts[1].trim());

				}
				if (line.contains("<14>")) {
					String[] parts=line.split("<14>");
					writer.println("<14>"+parts[1].trim());
				}
				if (line.contains("<29>")) {
					String[] parts=line.split("<29>");
					writer.println("<29>"+parts[1].trim());
				}
				line=reader.readLine();
				//int isFound = line.indexOf("<13>");
				//System.out.println(isFound);
				//System.out.println("length:"+line.length());
				//int len=line.length();


				
				/*int lnew=len-isFound;
				char[] destArray= new char[lnew];
				try {
					line.getChars(30,40,destArray,0);
					System.out.println(destArray);
				}
				catch(Exception ex) {
					System.out.println(ex);
					System.out.println("in here");
				}*/
			}
			reader.close();
			writer.close();
		}catch(IOException e) {
			e.printStackTrace();
			
		}		
	}
}
