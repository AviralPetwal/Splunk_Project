package log_parser;
import java.util.Vector;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Timestamp;
import java.util.Date;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.ArrayList;


public class HTTP_ReqRes3 {

    public static void conn_querry(StringBuffer response) throws Exception{
    	String conn_put_dir_temp="C:\\Users\\apetwal\\Documents\\prometheus-2.5.0.windows-amd64\\extracted_values\\ems_conn_extracted_Val.txt";
        PrintWriter conn_writer =new PrintWriter(conn_put_dir_temp);
        String put_full_dir_temp="C:\\Users\\apetwal\\Documents\\prometheus-2.5.0.windows-amd64\\prom_full.txt";
        PrintWriter fullwriter =new PrintWriter(put_full_dir_temp);
        //Read JSON response and print
        JSONObject myResponse = new JSONObject(response.toString());
        fullwriter.println(response.toString());
        System.out.println("result after Reading JSON Response");
        JSONObject data= myResponse.getJSONObject("data");
        JSONArray result= data.getJSONArray("result");
        for (int i=0;i<result.length();i++) {
      	  ArrayList<Object> combined=new ArrayList<Object>();
      	  JSONObject fullvalues = result.getJSONObject(i);
      	  JSONArray fvalue=fullvalues.getJSONArray("values");
//      	  System.out.println(length);
//      	  System.out.println(fvalue);
      	  for (int j=0;j<fvalue.length();j++) {
//      		  System.out.println(fvalue.getJSONArray(j));
//      		System.out.println();
          	  String temp=fvalue.getJSONArray(j).toString();
          	  String requiredString = temp.substring(temp.indexOf("[") + 1, temp.indexOf(","));
          	  String value = temp.substring(temp.indexOf("\"") + 1, temp.indexOf("\"]"));
//          	  System.out.println(requiredString);
          	  Timestamp ts= new Timestamp((long)Double.parseDouble(requiredString)*1000);
          	  Date date=new Date(ts.getTime());
//          	  System.out.println(date);
          	  combined.add(date);
      	  JSONObject metric=fullvalues.getJSONObject("metric");
   		  Object conn_url=metric.get("CONN_URL");
   		  combined.add(conn_url);
      	  Object customer_id=metric.get("CUSTOMER_ID");
   		  combined.add(customer_id);
   		  Object host=metric.get("HOST");
   		  combined.add(host);
   		  Object inst_name=metric.get("INST_NAME");
   		  combined.add(inst_name);
   		  Object machine_name=metric.get("MACHINE_NAME");
   		  combined.add(machine_name);
     	  Object metric_type=metric.get("METRIC_TYPE");
     	  combined.add(metric_type);
   		  Object user_name=metric.get("USER_NAME");
   		  combined.add(user_name);
   		  Object instance=metric.get("instance");
     	  combined.add(instance);
     	  Object job=metric.get("job");
   		  combined.add(job);
      	  combined.add(value);
   		  System.out.println(combined);                       	  
      	  conn_writer.println(combined.toString());
      	  combined.clear();
      	  }
        }
        conn_writer.close();
        fullwriter.close();
    }
    public static void inst_querry(StringBuffer response) throws Exception{
    	String inst_put_dir_temp="C:\\Users\\apetwal\\Documents\\prometheus-2.5.0.windows-amd64\\extracted_values\\ems_inst_extracted_Val.txt";
        PrintWriter inst_writer =new PrintWriter(inst_put_dir_temp);
        String put_full_dir_temp="C:\\Users\\apetwal\\Documents\\prometheus-2.5.0.windows-amd64\\prom_full.txt";
        PrintWriter fullwriter =new PrintWriter(put_full_dir_temp);
        //Read JSON response and print
        JSONObject myResponse = new JSONObject(response.toString());
        fullwriter.println(response.toString());
        System.out.println("result after Reading JSON Response");
        JSONObject data= myResponse.getJSONObject("data");
        JSONArray result= data.getJSONArray("result");
        for (int i=0;i<result.length();i++) {
      	  ArrayList<Object> combined=new ArrayList<Object>();
      	  JSONObject fullvalues = result.getJSONObject(i);
      	  JSONArray fvalue=fullvalues.getJSONArray("values");
//      	  System.out.println(length);
//      	  System.out.println(fvalue);
      	  for (int j=0;j<fvalue.length();j++) {
//      		  System.out.println(fvalue.getJSONArray(j));
//      		System.out.println();
          	  String temp=fvalue.getJSONArray(j).toString();
          	  String requiredString = temp.substring(temp.indexOf("[") + 1, temp.indexOf(","));
          	  String value = temp.substring(temp.indexOf("\"") + 1, temp.indexOf("\"]"));
//          	  System.out.println(requiredString);
          	  Timestamp ts= new Timestamp((long)Double.parseDouble(requiredString)*1000);
          	  Date date=new Date(ts.getTime());
//          	  System.out.println(date);
          	  combined.add(date);
      	  JSONObject metric=fullvalues.getJSONObject("metric");
      	  Object customer_id=metric.get("CUSTOMER_ID");
   		  combined.add(customer_id);
   		  Object inst_name=metric.get("INST_NAME");
   		  combined.add(inst_name);
   		  Object machine_name=metric.get("MACHINE_NAME");
   		  combined.add(machine_name);
     	  Object metric_type=metric.get("METRIC_TYPE");
     	  combined.add(metric_type);
   		  Object instance=metric.get("instance");
     	  combined.add(instance);
     	  Object job=metric.get("job");
   		  combined.add(job);
      	  combined.add(value);
   		  System.out.println(combined);                       	  
      	  inst_writer.println(combined.toString());
      	  combined.clear();
      	  }
        }
        inst_writer.close();
        fullwriter.close();
    }
    public static void queue_querry(StringBuffer response) throws Exception{
    	String queue_put_dir_temp="C:\\Users\\apetwal\\Documents\\prometheus-2.5.0.windows-amd64\\extracted_values\\ems_queue_extracted_Val.txt";
        PrintWriter queue_writer =new PrintWriter(queue_put_dir_temp);
        String put_full_dir_temp="C:\\Users\\apetwal\\Documents\\prometheus-2.5.0.windows-amd64\\prom_full.txt";
        PrintWriter fullwriter =new PrintWriter(put_full_dir_temp);
        //Read JSON response and print
        JSONObject myResponse = new JSONObject(response.toString());
        fullwriter.println(response.toString());
        System.out.println("result after Reading JSON Response");
        JSONObject data= myResponse.getJSONObject("data");
        JSONArray result= data.getJSONArray("result");
        for (int i=0;i<result.length();i++) {
      	  ArrayList<Object> combined=new ArrayList<Object>();
      	  JSONObject fullvalues = result.getJSONObject(i);
      	  JSONArray fvalue=fullvalues.getJSONArray("values");
//      	  System.out.println(length);
//      	  System.out.println(fvalue);
      	  for (int j=0;j<fvalue.length();j++) {
//      		  System.out.println(fvalue.getJSONArray(j));
//      		System.out.println();
          	  String temp=fvalue.getJSONArray(j).toString();
          	  String requiredString = temp.substring(temp.indexOf("[") + 1, temp.indexOf(","));
          	  String value = temp.substring(temp.indexOf("\"") + 1, temp.indexOf("\"]"));
//          	  System.out.println(requiredString);
          	  Timestamp ts= new Timestamp((long)Double.parseDouble(requiredString)*1000);
          	  Date date=new Date(ts.getTime());
//          	  System.out.println(date);
          	  combined.add(date);
          	  JSONObject metric=fullvalues.getJSONObject("metric");
          	  Object application_id=metric.get("APPLICATION_ID");
          	  combined.add(application_id);
          	  Object customer_id=metric.get("CUSTOMER_ID");
          	  combined.add(customer_id);
          	  Object dest_name=metric.get("DEST_NAME");
          	  combined.add(dest_name);
          	  Object dest_type=metric.get("DEST_TYPE");
          	  combined.add(dest_type);
          	  Object inst_name=metric.get("INST_NAME");
          	  combined.add(inst_name);
          	  Object machine_name=metric.get("MACHINE_NAME");
          	  combined.add(machine_name);
          	  Object metric_type=metric.get("METRIC_TYPE");
          	  combined.add(metric_type);
          	  Object instance=metric.get("instance");
          	  combined.add(instance);
          	  Object job=metric.get("job");
          	  combined.add(job);
          	  combined.add(value);
          	  System.out.println(combined);           	  
          	  queue_writer.println(combined.toString());
          	  combined.clear();
      	  }
        }
        queue_writer.close();
        fullwriter.close();
    }
    public static void durable_querry(StringBuffer response) throws Exception{
    	String durable_put_dir_temp="C:\\Users\\apetwal\\Documents\\prometheus-2.5.0.windows-amd64\\extracted_values\\ems_durable_extracted_Val.txt";
        PrintWriter durable_writer =new PrintWriter(durable_put_dir_temp);
        String put_full_dir_temp="C:\\Users\\apetwal\\Documents\\prometheus-2.5.0.windows-amd64\\prom_full.txt";
        PrintWriter fullwriter =new PrintWriter(put_full_dir_temp);
        //Read JSON response and print
        JSONObject myResponse = new JSONObject(response.toString());
        fullwriter.println(response.toString());
        System.out.println("result after Reading JSON Response");
        JSONObject data= myResponse.getJSONObject("data");
        JSONArray result= data.getJSONArray("result");
        for (int i=0;i<result.length();i++) {
      	  ArrayList<Object> combined=new ArrayList<Object>();
      	  JSONObject fullvalues = result.getJSONObject(i);
      	  JSONArray fvalue=fullvalues.getJSONArray("values");
//      	  System.out.println(length);
//      	  System.out.println(fvalue);
      	  for (int j=0;j<fvalue.length();j++) {
//      		  System.out.println(fvalue.getJSONArray(j));
//      		System.out.println();
          	  String temp=fvalue.getJSONArray(j).toString();
          	  String requiredString = temp.substring(temp.indexOf("[") + 1, temp.indexOf(","));
          	  String value = temp.substring(temp.indexOf("\"") + 1, temp.indexOf("\"]"));
//          	  System.out.println(requiredString);
          	  Timestamp ts= new Timestamp((long)Double.parseDouble(requiredString)*1000);
          	  Date date=new Date(ts.getTime());
//          	  System.out.println(date);
          	  combined.add(date);
          	JSONObject metric=fullvalues.getJSONObject("metric");
        	  Object application_id=metric.get("APPLICATION_ID");
        	  combined.add(application_id);
        	  Object customer_id=metric.get("CUSTOMER_ID");
        	  combined.add(customer_id);
        	  Object durable_name=metric.get("DURABLE_NAME");
        	  combined.add(durable_name);
        	  Object inst_name=metric.get("INST_NAME");
     		  combined.add(inst_name);
         	  Object machine_name=metric.get("MACHINE_NAME");
       		  combined.add(machine_name);
         	  Object metric_type=metric.get("METRIC_TYPE");
       		  combined.add(metric_type);
         	  Object topic_name=metric.get("TOPIC_NAME");
       		  combined.add(topic_name);
         	  Object user_name=metric.get("USER_NAME");
       		  combined.add(user_name);
       		  Object instance=metric.get("instance");
       		  combined.add(instance);
         	  Object job=metric.get("job");
         	  combined.add(job);
       		  combined.add(value);
     		 System.out.println(combined);
     		durable_writer.println(combined.toString());
//     		test_md_vector.addAll(test_combined);
     		 combined.clear();
         	  
      	  }
      }
        durable_writer.close();
        fullwriter.close();
    }
	public static void call_me() throws Exception 
               {
            	   
                              //String url = "https://api.lufthansa.com/v1/references/countries/DK?limit=20&offset=0";
                              //String url = "http://171.17.23.33:9090/api/v1/query?query=probe_success";
            	   			String querry="EMS_QUEUE_STAT";
            	   			String start_date="2019-05-04";
            	   			String start_time="04:00:00";
            	   			String end_date="2019-05-04";
            	   			String end_time="12:00:00";
            	   			String step_size="15s";
                              String url = "http://171.17.24.25:9090/api/v1/query_range?query="+querry+"&start="+start_date+"T"+start_time+"Z&end="+end_date+"T"+end_time+"Z&step="+step_size;
//                            String full_querry="http://171.17.24.25:9090/api/v1/query_range?query=EMS_DURABLE_STAT&start=2019-03-06T00:00:10Z&end=2019-03-06T00:00:11Z&step=15s";
//                              String Start_Date="2019-01-31";
//                              String Start_Time="20:10:30";
//                              String End_Date="2019-01-31";
//                              String End_Time="20:11:00";
//                              String Step_Interval="15s";
//                              String url = "http://171.17.23.33:9090/api/v1/query_range?query=probe_success&start="+Start_Date+"T"+Start_Time+".781Z&end="+End_Date+"T21:11:00.781Z&step="+Step_Interval;
//                              String url = "http://171.17.23.33:9090/api/v1/query?query=probe_success&time=2018-12-04T20:11:00.781Z";
                              
//                              String url = "http://localhost:9090/api/v1/query?query="+querry+"&time="+start_time+"T"+start_time+".781Z";
                              //String url = "http://localhost:9090/api/v1/query_range?query=e2e_pinger_service_group_response_status_code&start=2018-12-31T20:10:30.781Z&end=2019-01-01T23:11:00.781Z&step=45s";
                              
                              URL obj = new URL(url);
                              
                              //HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
                              HttpURLConnection con = (HttpURLConnection) obj.openConnection();
                              
                              // optional default is GET
                              con.setRequestMethod("GET");
                              //add request header
                              //con.setRequestProperty("User-Agent", "Mozilla/5.0");
                              
                              /*con.setRequestProperty("Authorization", "Bearer " + "bdrfztcp77jmkbm79md29795");
                              con.setRequestProperty("Content-Type", "application/json");
                              con.setRequestProperty("Accept", "application/json");
                              */
                              
                              System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
                              
                              int responseCode = con.getResponseCode();
                              System.out.println("\nSending 'GET' request to URL : " + url);
                              System.out.println("Response Code : " + responseCode);
                              BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                              String inputLine;
                              StringBuffer response = new StringBuffer();
                              while ((inputLine = in.readLine()) != null) {
                                             response.append(inputLine);
                              }
                              in.close();

                              //print in String
                              System.out.println(response.toString());
                              switch(querry) {
                              case "EMS_CONNECTION_STAT":
                            	  System.out.println("In_Connection");
                            	  conn_querry(response);
                            	  break;
                              case "EMS_QUEUE_STAT":
                            	  System.out.println("In_queue");
                            	  queue_querry(response);
                            	  break;
                              case "EMS_INSTANCE_STAT":
                            	  System.out.println("In_Instance");
                            	  inst_querry(response);
                            	  break;
                              case "EMS_DURABLE_STAT":
                            	  System.out.println("In_Durable");
                            	  durable_querry(response);
                              }
                
               }

               public static void main(String[] args) {
                              try {
                                             //Send_HTTP_Request.call_me();
                                             HTTP_ReqRes3.call_me();
                                             System.out.println("Done Fetching");
                              } catch (Exception e) {
                                             e.printStackTrace();
                              }
               }
}
